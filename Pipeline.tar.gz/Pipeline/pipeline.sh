#!/bin/zsh

#Lets get our conda environment set up

# Use source to initialize conda with .zshrc
source ~/.zshrc

# CONDA_SUBDIR=osx-64 conda create -n fin_pipe -y

#Activate conda script
conda activate fin_pipe

# =====================
# Genotyping with MLST
# =====================
conda install -c bioconda mlst -y
# Set up directories
mkdir -p "$HOME/Pipeline_G3/output"
mkdir -p "$HOME/Pipeline_G3/logs"

INPUT_DIR="$HOME/Pipeline_G3/asm"
OUTPUT_DIR="$HOME/Pipeline_G3/output"
LOG_DIR="$HOME/Pipeline_G3/logs"

# Define log files
STDOUT_LOG="$LOG_DIR/mlst_stdout.log"
STDERR_LOG="$LOG_DIR/mlst_stderr.log"
MLST_RAW_OUTPUT="$OUTPUT_DIR/mlst_raw_results.tsv"
MLST_FINAL_OUTPUT="$OUTPUT_DIR/mlst_results.tsv"


# Add header to final output
echo -e "Sample\tSpecies\tST\tabcZ\tadk\taroE\tfumC\tgdh\tpdhC\tpgm" > "$MLST_FINAL_OUTPUT"

# Run MLST on all .fna files safely
if ls "$INPUT_DIR"/*.fna 1> /dev/null 2>&1; then
    for fna_file in "$INPUT_DIR"/*.fna; do
        echo "Processing: $fna_file" | tee -a "$STDOUT_LOG"
        mlst "$fna_file" >> "$MLST_RAW_OUTPUT" 2>> "$STDERR_LOG"
    done

    # Process the raw MLST output correctly for ALL rows
    awk -F'\t' '{
        split($1, path, "/"); 
        split(path[length(path)], name, "_"); 
        sample=name[1]; 
        print sample "\t" $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6 "\t" $7 "\t" $8 "\t" $9 "\t" $10;
    }' "$MLST_RAW_OUTPUT" >> "$MLST_FINAL_OUTPUT"

else
    echo "No .fna files found in $INPUT_DIR" | tee -a "$STDERR_LOG"
fi

echo "MLST analysis complete. Results saved to $MLST_FINAL_OUTPUT"
echo "Check logs in $LOG_DIR for details."

# ==============================================
# Taxonomic Classification Genus Level with 16S
# ==============================================

conda install -c bioconda -c conda-forge barrnap bedtools pigz -y

# Set up directories
mkdir -pv "$OUTPUT_DIR/16S_output"

SIXTEEN_S_OUTPUT="$OUTPUT_DIR/16S_output"

# Define log files
STDOUT_LOG="$LOG_DIR/16S_stdout.log"
STDERR_LOG="$LOG_DIR/16S_stderr.log"

# Define combined output file
COMBINED_OUTPUT="$OUTPUT_DIR/combined_16S.fa"

#Run barnnap to get 16S sequeces from assembly
# Loop through each .fna file in the input directory
for fna_file in "$INPUT_DIR"/*.fna; do
    # Get the base name of the .fna file (e.g., assembly.fna -> assembly)
    base_name=$(basename "$fna_file" .fna)
    
    # Remove the "_filtered_assembly" part from the sample name
    sample_name=$(echo "$base_name" | sed 's/_filtered_assembly//')

    # Run Barrnap to get 16S rRNA region and output to a temporary GFF file
    echo "Processing: $fna_file" >> "$STDOUT_LOG"
    
    barrnap "$fna_file" \
    | grep "Name=16S_rRNA;product=16S ribosomal RNA" \
    > "$SIXTEEN_S_OUTPUT/${base_name}_16S.gff" 2>> "$STDERR_LOG"
    
    # Check if the GFF file was created and has content
    if [ -s "$SIXTEEN_S_OUTPUT/${base_name}_16S.gff" ]; then
        # Use bedtools to extract 16S rRNA sequence from the genomic assembly
        bedtools getfasta \
        -fi "$fna_file" \
        -bed "$SIXTEEN_S_OUTPUT/${base_name}_16S.gff" -s \
        -fo "$SIXTEEN_S_OUTPUT/${base_name}_16S.fa" 2>> "$STDERR_LOG"
        
        # Modify the FASTA header to be just the sample name (without the prefix or suffix)
        awk -v sample="$sample_name" '{if($0 ~ />/) {print ">" sample} else {print $0}}' "$SIXTEEN_S_OUTPUT/${base_name}_16S.fa" >> "$COMBINED_OUTPUT"
        
        # Log successful extraction
        echo "16S extraction for $sample_name completed." >> "$STDOUT_LOG"
    else
        # Log if no 16S rRNA was found
        echo "No 16S rRNA found in $base_name" >> "$STDERR_LOG"
    fi
done

echo "16S extraction completed for all files." >> "$STDOUT_LOG"
echo "Combined FASTA file saved to $COMBINED_OUTPUT."

#Run RDP to get genus from 16S sequences

# Navigate to the output directory
cd ~/Pipeline_G3/output/

# Pull the Docker image
docker pull compmetagen/rdpclassifier 

# Run the container, mount the directory, and execute the command
docker run --platform linux/amd64 -t -i -v ~/Pipeline_G3/output:/rdp -w /rdp compmetagen/rdpclassifier /bin/bash -c "java -Xmx2g -jar \$RDPPATH/dist/classifier.jar classify combined_16S.fa -o RDP_output.tsv"


cd ~/Pipeline_G3/

# ==============================================
# Taxonomic Classification Genus Level with FastANI
# ==============================================


###

conda install -c bioconda -c conda-forge sra-tools pigz fastani

#Make reference folder with our reference genomes
mkdir -pv ./ref
cd ./ref
 
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/046/055/GCF_000046055.1_ASM4605v1/GCF_000046055.1_ASM4605v1_genomic.fna.gz
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/020/170/975/GCF_020170975.1_ASM2017097v1/GCF_020170975.1_ASM2017097v1_genomic.fna.gz
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/900/087/635/GCF_900087635.2_WHOF/GCF_900087635.2_WHOF_genomic.fna.gz
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/006/845/GCF_000006845.1_ASM684v1/GCF_000006845.1_ASM684v1_genomic.fna.gz
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/008/805/GCF_000008805.1_ASM880v1/GCF_000008805.1_ASM880v1_genomic.fna.gz
gunzip -kv *.fna.gz
 
cd ../

set -eo pipefail

#Make output folder
mkdir -pv ./output/fastani_results

# Directory setup and structure
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUT_DIR="./output/fastani_results"
REF_DIR="./ref"          # reference genomes here (*.fasta)
QUERY_DIR="./asm"           # query genomes here (*.fasta)
LOG_DIR="./logs"
THREADS=8                     

mkdir -p "${OUT_DIR}/logs" "${REF_DIR}" "${QUERY_DIR}"

# Create logfile
exec > >(tee "${LOG_DIR}/fastani.log") 2>&1

# Create sample/reference files 
find "${REF_DIR}" -name '*.fna' > "${OUT_DIR}/ref_list.txt"
find "${QUERY_DIR}" -name '*.fna' > "${OUT_DIR}/query_list.txt"

# Check input files
[ -s "${OUT_DIR}/ref_list.txt" ] || { echo "Error: No reference genomes found"; exit 1; }
[ -s "${OUT_DIR}/query_list.txt" ] || { echo "Error: No query genomes found"; exit 1; }

# Create output file
FINAL_FILE="${OUT_DIR}/fastani_results.tsv"

# Run fastani
echo "[$(date)] Starting analysis..."
fastANI --ql "${OUT_DIR}/query_list.txt" \
        --rl "${OUT_DIR}/ref_list.txt" \
        --matrix \
        -t "${THREADS}" \
        -o "${OUT_DIR}/raw_results.txt"

echo "[$(date)] Processing results..."

echo -e "Sample\tReference\t%ANI\tNum_Fragments_Mapped\tTotal_Query_Fragments\t%Query_Aligned\tBasepairs_Query_Aligned" > "$FINAL_FILE"

# Create .tsv file with results metrics 
awk -F' ' '
{
    split($1, qpath, "/");
    split($2, rpath, "/");
    query = qpath[length(qpath)];
    ref = rpath[length(rpath)];
    
    sub(/filtered_assembly/, "", query);
    sub(/\..*/, "", query);  # Remove extensions
    sub(/\..*/, "", ref);    # Remove extensions

    ani = $3;
    mapped = $4;
    total = $5;
    pct_aligned = (total > 0) ? (mapped/total)*100 : 0;
    bp_aligned = mapped * 3000;  # Assuming 3kbp fragments
    
    print query "\t" ref "\t" ani "\t" mapped "\t" total "\t" pct_aligned "\t" bp_aligned
}' "${OUT_DIR}/raw_results.txt" | sort -k1,1 -k3,3nr >> "$FINAL_FILE"

echo "[$(date)] Analysis complete!"
echo "Results saved to: ${FINAL_FILE}"

# ==============================================
# Genome Assembly Quality Assessment with CheckM
# ==============================================

conda install -c bioconda numpy matplotlib pysam -y 
conda install -c bioconda hmmer -y 
conda install bioconda::prodigal -y

pip3 install checkm-genome 

# Create necessary directories
mkdir -pv ~/Pipeline_G3/output/checkm/db 
cd ~/Pipeline_G3/output/checkm/db




# Download CheckM database
curl -O https://zenodo.org/records/7401545/files/checkm_data_2015_01_16.tar.gz 
tar zxvf checkm_data_2015_01_16.tar.gz

# Set environment variable for CheckM database
echo 'export CHECKM_DATA_PATH=$HOME/Pipeline_G3/output/checkm/db' >> ~/.zshrc
echo "${CHECKM_DATA_PATH}" 

source ~/.zshrc

conda activate fin_pipe

# Move to CheckM working directory
cd ~/Pipeline_G3/output/checkm

# Create a logs directory
mkdir -pv ~/Pipeline_G3/logs

# Run CheckM analysis
checkm taxon_list | grep Neisseria >> checkm.stdout.log 2>> checkm.stderr.log
checkm taxon_set species "Neisseria gonorrhoeae" Ng.markers >> checkm.stdout.log 2>> checkm.stderr.log

checkm \
      analyze \
      Ng.markers \
      ~/Pipeline_G3/asm \
      analyze_output >> checkm.stdout.log 2>> checkm.stderr.log

checkm \
      qa \
      -f checkm.tax.qa.out \
      -o 1 \
      Ng.markers \
      analyze_output >> checkm.stdout.log 2>> checkm.stderr.log

# Convert .out file to .tsv file
awk 'BEGIN {OFS="\t"} {print $0}' checkm.tax.qa.out > checkm.tax.qa.tsv

# Move log files to logs directory
mv checkm.stdout.log checkm.stderr.log ~/Pipeline_G3/logs

# Format and display results
column -ts $'\t' checkm.tax.qa.tsv | less -S

#==========================================================
#Genome Assembly Intracontig Quality Assessment with MMSeq2
#===========================================================

######################################################
#### Downloading top neisseria gonorhoae genomes #####
######################################################

cd ~/Pipeline_G3/

mkdir -p ~/Pipeline_G3/nes_top_genomes
cd ~/Pipeline_G3/nes_top_genomes

wget -O GCF_013030075.1.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/013/030/075/GCF_013030075.1_ASM1303007v1/GCF_013030075.1_ASM1303007v1_genomic.fna.gz 
wget -O GCF_900087635.2.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/900/087/635/GCF_900087635.2_WHOF/GCF_900087635.2_WHOF_genomic.fna.gz
wget -O GCF_000006845.1.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/006/845/GCF_000006845.1_ASM684v1/GCF_000006845.1_ASM684v1_genomic.fna.gz
wget -O GCF_000008805.1.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/008/805/GCF_000008805.1_ASM880v1/GCF_000008805.1_ASM880v1_genomic.fna.gz
gunzip ./*
cd ..

######################################################
#### Downloading contaminant reference genomes #######
######################################################

mkdir -p ~/Pipeline_G3/contaminants
cd ~/Pipeline_G3/contaminants

# to download reference contaminant genomes
wget -O GCF_000006765.1_PA.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/006/765/GCF_000006765.1_ASM676v1/GCF_000006765.1_ASM676v1_genomic.fna.gz 
wget -O GCF_000008865.2_EC.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/008/865/GCF_000008865.2_ASM886v2/GCF_000008865.2_ASM886v2_genomic.fna.gz
wget -O GCF_000240185.1_KP.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/240/185/GCF_000240185.1_ASM24018v2/GCF_000240185.1_ASM24018v2_genomic.fna.gz
wget -O GCF_000013425.1_SA.fna.gz https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/013/425/GCF_000013425.1_ASM1342v1/GCF_000013425.1_ASM1342v1_genomic.fna.gz
gunzip ./* # unzip the contaminant genomes
cd ..


cat ~/Pipeline_G3/nes_top_genomes/* >> ~/Pipeline_G3/combined_top_ns.fna # combine top reference genomes together
cat ~/Pipeline_G3/contaminants/* >> ~/Pipeline_G3/combined_contam.fna # combine contaminant genomes together
cat ~/Pipeline_G3/combined_top_ns.fna ~/Pipeline_G3/combined_contam.fna > ~/Pipeline_G3/all_top_genomes.fna  # combine neisseria and contaominants reference genomes together



# Since we're combining contigs across all samples, we want to keep the sample information, so adding it in the fasta file of the contigs
# Loop through each file in the directory
for file in ~/Pipeline_G3/asm/*.fna; do
    # Extract the unique ID using parameter substitution
    base_name=$(basename "$file")  # gets filename (i.e. A2128705filtered_assembly.fna)
    sample_id=${base_name%%filtered_assembly.fna}  # remove the suffix (i.e. A2128705)

    sed -i '' "s/^>/>${sample_id}_/g" "$file" # prepending sample name to fasta header

    echo "Processed: $base_name"
    echo "Sample ID: $sample_id"
done

bash mmseq_downloading_contigs.sh # combine all contigs together

######################################################
################# Run MMseq ##########################
######################################################

conda install -c conda-forge -c bioconda mmseqs2 -y
mkdir -p ~/Pipeline_G3/output/mmseq
mkdir -p ~/Pipeline_G3/output/mmseq/tmp


mmseqs createdb ~/Pipeline_G3/output/combined_contigs.fna ~/Pipeline_G3/output/mmseq/combined_contigs_db_nu # create contig database (nu)
mmseqs translatenucs ~/Pipeline_G3/output/mmseq/combined_contigs_db_nu ~/Pipeline_G3/output/mmseq/combined_contigs_db_p #translate contig db to protein

mmseqs createdb ~/Pipeline_G3/all_top_genomes.fna ~/Pipeline_G3/output/mmseq/top_ref_contam_db_n # create nesseria gonorhoae + contaminants db (nu)
mmseqs translatenucs ~/Pipeline_G3/output/mmseq/top_ref_contam_db_n ~/Pipeline_G3/output/mmseq/top_ref_contam_db_p #translate contig db to protein

# mmseqs search ./mmseq/combined_contigs_db_p ./mmseq/ref_contam_db_p ./mmseq/all_result ./mmseq/tmp --threads 4
mmseqs search ~/Pipeline_G3/output/mmseq/combined_contigs_db_p ~/Pipeline_G3/output/mmseq/top_ref_contam_db_p ~/Pipeline_G3/output/mmseq/top_all_result ~/Pipeline_G3/output/mmseq/tmp # > ~/Pipeline_G3/logs/top_mmseq_output.log 2>&1 

# mmseqs convertalis ./mmseq/combined_contigs_db_p ./mmseq/ref_contam_db_p ./mmseq/all_result ./mmseq/all_result.m8
mmseqs convertalis ~/Pipeline_G3/output/mmseq/combined_contigs_db_p ~/Pipeline_G3/output/mmseq/top_ref_contam_db_p ~/Pipeline_G3/output/mmseq/top_all_result ~/Pipeline_G3/output/mmseq/top_all_result.m8 # > ~/Pipeline_G3/logs/top_mmseq_output_m8.log 2>&1 


conda deactivate
