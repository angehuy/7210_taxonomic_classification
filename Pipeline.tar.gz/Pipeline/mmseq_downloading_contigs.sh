#!/bin/bash

# Define output file
output_fasta="./output/combined_contigs.fna"


# Loop through each directory inside bacteria/
for file in ./asm/*; do
    echo "Processing $file..."
    cat "$file" >> "$output_fasta"

done

echo "All assemblies have been combined into $output_fasta."
